import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { MapPin, Navigation, Search } from "lucide-react";
import { supabase } from "@/services/supabase";
import { Card, Badge, LoadingState, EmptyState } from "@/components/ui";
import { haversineKm } from "@/utils/constants";
import type { TouristLocation } from "@/types";

const CATEGORIES = [
  { value: "", label: "All" },
  { value: "PARKS", label: "Parks" },
  { value: "HERITAGE", label: "Heritage" },
  { value: "LAKES", label: "Lakes" },
  { value: "TEMPLES", label: "Temples" },
  { value: "TOURIST_ATTRACTIONS", label: "Tourist Attractions" },
];

export default function Explore() {
  const [category, setCategory] = useState("");
  const [search, setSearch] = useState("");
  const [userLoc, setUserLoc] = useState<{ lat: number; lng: number } | null>(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setUserLoc({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        () => {}
      );
    }
  }, []);

  const { data: locations, isLoading } = useQuery<TouristLocation[]>({
    queryKey: ["tourist-locations"],
    queryFn: async () => {
      const { data, error } = await supabase.from("tourist_locations").select("*").order("name");
      if (error) throw error;
      return data as TouristLocation[];
    },
  });

  const filtered = locations
    ?.filter((l) => !category || l.category === category)
    .filter((l) => !search || l.name.toLowerCase().includes(search.toLowerCase()))
    .map((l) => ({
      ...l,
      distance: userLoc ? haversineKm(userLoc.lat, userLoc.lng, l.latitude, l.longitude) : null,
    }))
    .sort((a, b) => (a.distance ?? 999) - (b.distance ?? 999)) || [];

  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-navy-900 flex items-center gap-2">
          <MapPin className="w-6 h-6 text-success-600" /> Explore Nagpur
        </h1>
        <p className="text-sm text-gray-500 mt-1">Discover parks, lakes, temples, heritage sites and more</p>
      </div>

      <div className="flex flex-wrap gap-2 mb-6">
        {CATEGORIES.map((c) => (
          <button
            key={c.value}
            onClick={() => setCategory(c.value)}
            className={`rounded-full border px-4 py-1.5 text-sm font-medium transition ${
              category === c.value ? "bg-brand-600 text-white border-brand-600" : "bg-white border-gray-200 text-navy-700 hover:bg-gray-50"
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>

      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          type="text"
          placeholder="Search places..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full rounded-xl border border-gray-200 bg-white pl-10 pr-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-200 focus:border-brand-400 transition"
        />
      </div>

      {isLoading ? (
        <LoadingState message="Loading places..." />
      ) : filtered.length === 0 ? (
        <Card className="p-6">
          <EmptyState icon={<MapPin className="w-12 h-12" />} title="No places found" message="Try a different category or search." />
        </Card>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((loc) => (
            <Card key={loc.id} className="overflow-hidden">
              <div className="h-32 bg-gradient-to-br from-navy-100 to-brand-100 flex items-center justify-center">
                <MapPin className="w-10 h-10 text-navy-300" />
              </div>
              <div className="p-4">
                <Badge className="bg-gray-50 text-gray-600 border-gray-200 mb-2">{loc.category.replace("_", " ")}</Badge>
                <p className="text-sm font-semibold text-navy-800">{loc.name}</p>
                <p className="text-xs text-gray-500 mt-1 line-clamp-2">{loc.description}</p>
                {loc.distance !== null && (
                  <p className="text-xs text-brand-600 font-medium mt-2">{loc.distance.toFixed(1)} km away</p>
                )}
                <a
                  href={`https://www.openstreetmap.org/directions?from=${userLoc ? `${userLoc.lat},${userLoc.lng}` : ""}&to=${loc.latitude},${loc.longitude}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-3 inline-flex items-center gap-1.5 text-sm text-brand-600 font-medium hover:underline"
                >
                  <Navigation className="w-3.5 h-3.5" /> Directions
                </a>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
