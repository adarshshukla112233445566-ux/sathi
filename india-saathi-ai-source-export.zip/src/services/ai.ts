import { supabase } from "@/services/supabase";
import type { AnalysisResult, ComplaintCategory } from "@/types";

export async function analyzeComplaint(input: {
  category: string;
  title: string;
  description: string;
  latitude?: number;
  longitude?: number;
}): Promise<AnalysisResult> {
  const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/analyze-complaint`;
  const { data: session } = await supabase.auth.getSession();
  const token = session.session?.access_token;

  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      apikey: import.meta.env.VITE_SUPABASE_ANON_KEY,
    },
    body: JSON.stringify(input),
  });

  if (!res.ok) {
    throw new Error(`AI analysis failed (${res.status})`);
  }

  const data = await res.json();
  if (data.error) throw new Error(data.error);

  return {
    category: data.category as ComplaintCategory,
    confidence: Number(data.confidence) || 0,
    severity: data.severity,
    priorityScore: Number(data.priorityScore ?? data.priority_score ?? 50),
    department: data.department,
    reason: data.reason,
  };
}

export async function uploadImage(file: File): Promise<string> {
  const ext = file.name.split(".").pop() || "jpg";
  const path = `complaints/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;

  const { error } = await supabase.storage
    .from("complaints")
    .upload(path, file, { cacheControl: "3600", upsert: false });

  if (error) throw new Error(`Image upload failed: ${error.message}`);

  const { data } = supabase.storage.from("complaints").getPublicUrl(path);
  return data.publicUrl;
}
