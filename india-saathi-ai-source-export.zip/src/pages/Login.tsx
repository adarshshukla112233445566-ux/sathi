import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  ArrowRight,
  BellRing,
  ChevronDown,
  Eye,
  EyeOff,
  Globe2,
  Lightbulb,
  Lock,
  Mail,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { useAuth } from "@/store/auth";

const INDIA_GATE_IMAGE =
  "https://images.pexels.com/photos/19756444/pexels-photo-19756444.jpeg?auto=compress&cs=tinysrgb&w=1800";

const schema = z.object({
  email: z.string().email("Enter a valid email address"),
  password: z.string().min(1, "Password is required"),
});

type FormData = z.infer<typeof schema>;

function BrandMark({ light = false }: { light?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <img src="/image.png" alt="Indian Saathi AI" className="h-14 w-14 shrink-0 object-contain" />
      <div>
        <p className={`text-[19px] font-extrabold leading-none tracking-tight ${light ? "text-white" : "text-navy-900"}`}>
          INDIAN SAATHI <span className="text-saffron-500">AI</span>
        </p>
        <p className={`mt-1 text-[10px] font-medium ${light ? "text-white/80" : "text-navy-700"}`}>
          One AI-powered platform for a smarter, safer India.
        </p>
      </div>
    </div>
  );
}

export default function Login() {
  const { signIn, signInWithGoogle } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(true);
  const [serverError, setServerError] = useState("");
  const [googleError, setGoogleError] = useState("");
  const [loading, setLoading] = useState(false);

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<FormData>({ resolver: zodResolver(schema) });

  async function authenticate(email: string, password: string) {
    setServerError("");
    setLoading(true);
    try {
      await signIn(email, password);
      if (remember) localStorage.setItem("indian-saathi-remember", "true");
      const from = (location.state as { from?: { pathname: string } })?.from?.pathname;
      navigate(from || "/dashboard", { replace: true });
    } catch (err) {
      setServerError(err instanceof Error ? err.message : "Unable to sign in. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  async function onSubmit(data: FormData) {
    await authenticate(data.email, data.password);
  }

  async function useDemoAccess() {
    setValue("email", "demo@indiasaathi.ai");
    setValue("password", "password123");
    await authenticate("demo@indiasaathi.ai", "password123");
  }

  return (
    <main className="min-h-screen bg-[#f7f9fc] text-navy-900 lg:grid lg:grid-cols-[minmax(0,1.03fr)_minmax(520px,0.97fr)]">
      <section className="relative min-h-[620px] overflow-hidden bg-[#f5d5b5] lg:min-h-screen">
        <img
          src={INDIA_GATE_IMAGE}
          alt="India Gate at sunrise"
          className="absolute inset-0 h-full w-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(255,246,232,.82)_0%,rgba(255,246,232,.36)_45%,rgba(255,203,135,.12)_100%)]" />
        <div className="absolute inset-0 bg-[linear-gradient(0deg,rgba(4,20,45,.28)_0%,transparent_34%,rgba(255,247,234,.12)_100%)]" />

        <div className="relative z-10 flex h-full min-h-[620px] flex-col px-7 py-8 sm:px-12 lg:px-[7.5%] lg:py-12 xl:px-[9%]">
          <BrandMark />

          <div className="mt-20 max-w-[500px] sm:mt-24 lg:mt-[15vh]">
            <p className="mb-3 text-xs font-bold uppercase tracking-[0.22em] text-navy-700">A smarter India starts here</p>
            <h1 className="text-[clamp(2.7rem,4.7vw,4.35rem)] font-extrabold leading-[1.06] tracking-[-0.045em] text-[#073b82]">
              Your AI-powered Saathi
              <br />
              for a <span className="text-saffron-500">Smarter</span> <span className="text-success-600">India</span>
            </h1>
            <p className="mt-6 max-w-[440px] text-base font-medium leading-7 text-navy-800 sm:text-lg">
              Report civic issues, find essential services, get emergency assistance and connect with the right department — all from one platform.
            </p>
          </div>

          <div className="mt-9 grid max-w-[530px] grid-cols-3 gap-3 sm:gap-6">
            {[
              { icon: Sparkles, label: "AI-powered", sub: "civic assistance" },
              { icon: ShieldCheck, label: "Smart complaint", sub: "routing" },
              { icon: BellRing, label: "Emergency &", sub: "essential services" },
            ].map(({ icon: Icon, label, sub }) => (
              <div key={label} className="text-navy-900">
                <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full border border-white/80 bg-white/55 shadow-sm backdrop-blur-sm">
                  <Icon className="h-5 w-5 text-[#073b82]" />
                </div>
                <p className="text-xs font-bold leading-4 sm:text-sm">{label}<br />{sub}</p>
              </div>
            ))}
          </div>

          <div className="relative mt-auto hidden max-w-[430px] overflow-hidden rounded-[28px] border border-white/20 bg-navy-950/75 px-6 py-4 text-white shadow-xl backdrop-blur-md sm:block lg:mb-28">
            <div className="flex items-center gap-4">
              <div className="flex h-11 w-11 items-center justify-center rounded-full border border-white/60">
                <Sparkles className="h-5 w-5 text-saffron-400" />
              </div>
              <p className="text-sm font-semibold leading-6">A cleaner <span className="mx-2 text-saffron-400">•</span> Safer <span className="mx-2 text-success-400">•</span> More connected<br />India, together with AI</p>
            </div>
          </div>
        </div>

        <div className="pointer-events-none absolute -bottom-9 -left-8 h-32 w-[62%] rotate-[-8deg] rounded-[50%] border-[10px] border-saffron-500 opacity-90" />
        <div className="pointer-events-none absolute -bottom-16 -left-5 h-32 w-[68%] rotate-[-8deg] rounded-[50%] border-[10px] border-white opacity-95" />
        <div className="pointer-events-none absolute -bottom-24 left-3 h-32 w-[70%] rotate-[-8deg] rounded-[50%] border-[10px] border-success-600 opacity-90" />
      </section>

      <section className="relative flex min-h-screen items-center justify-center overflow-hidden px-5 py-10 sm:px-10 lg:px-14 xl:px-20">
        <div className="pointer-events-none absolute right-0 top-0 h-24 w-64 overflow-hidden opacity-90">
          <div className="absolute -right-14 -top-16 h-32 w-80 rotate-12 rounded-[50%] border-[7px] border-saffron-500" />
          <div className="absolute -right-14 -top-12 h-32 w-80 rotate-12 rounded-[50%] border-[7px] border-white" />
          <div className="absolute -right-14 -top-8 h-32 w-80 rotate-12 rounded-[50%] border-[7px] border-success-600" />
        </div>
        <div className="pointer-events-none absolute bottom-0 right-0 h-36 w-72 opacity-10 [background-image:radial-gradient(circle_at_50%_100%,#073b82_2px,transparent_3px),linear-gradient(90deg,transparent,rgba(19,136,8,.4))] [background-size:22px_22px,100%_100%]" />

        <div className="relative z-10 w-full max-w-[470px]">
          <div className="mb-6 flex justify-end">
            <button type="button" className="inline-flex items-center gap-2 rounded-xl border border-[#d8e0eb] bg-white px-4 py-2.5 text-xs font-semibold text-navy-700 shadow-sm transition hover:border-[#b8c7dc]">
              <Globe2 className="h-4 w-4 text-[#073b82]" /> English <ChevronDown className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="rounded-[25px] border border-white bg-white/95 p-7 shadow-[0_18px_60px_rgba(22,51,88,0.10)] sm:p-10">
            <BrandMark />
            <div className="mt-8">
              <h2 className="text-[2rem] font-extrabold tracking-[-0.04em] text-[#102f5f]">Welcome back</h2>
              <p className="mt-1 text-sm text-slate-500">Sign in to continue to Indian Saathi AI</p>
            </div>

            {serverError && <div className="mt-5 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{serverError}</div>}
            {googleError && <div className="mt-5 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{googleError.includes("provider") || googleError.includes("not enabled") ? "Google sign-in is not enabled for this project yet. Please use email sign-in, or enable Google under Supabase Authentication providers." : googleError}</div>}

            <form onSubmit={handleSubmit(onSubmit)} className="mt-7 space-y-5">
              <div>
                <label className="mb-2 block text-sm font-bold text-navy-900">Email address</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <input {...register("email")} type="email" placeholder="Enter your email address" className="h-12 w-full rounded-xl border border-[#d9e1ec] bg-white pl-11 pr-4 text-sm text-navy-900 outline-none transition placeholder:text-slate-400 focus:border-[#073b82] focus:ring-4 focus:ring-blue-50" />
                </div>
                {errors.email && <p className="mt-1.5 text-xs text-red-600">{errors.email.message}</p>}
              </div>

              <div>
                <label className="mb-2 block text-sm font-bold text-navy-900">Password</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <input {...register("password")} type={showPassword ? "text" : "password"} placeholder="Enter your password" className="h-12 w-full rounded-xl border border-[#d9e1ec] bg-white pl-11 pr-12 text-sm text-navy-900 outline-none transition placeholder:text-slate-400 focus:border-[#073b82] focus:ring-4 focus:ring-blue-50" />
                  <button type="button" onClick={() => setShowPassword((value) => !value)} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 transition hover:text-navy-800" aria-label={showPassword ? "Hide password" : "Show password"}>
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                {errors.password && <p className="mt-1.5 text-xs text-red-600">{errors.password.message}</p>}
              </div>

              <div className="flex items-center justify-between gap-3 text-xs">
                <label className="flex cursor-pointer items-center gap-2 font-semibold text-slate-600">
                  <input type="checkbox" checked={remember} onChange={(event) => setRemember(event.target.checked)} className="h-4 w-4 rounded border-slate-300 accent-[#073b82]" />
                  Remember me
                </label>
                <Link to="/forgot-password" className="font-bold text-[#0b55a0] hover:underline">Forgot password?</Link>
              </div>

              <button type="submit" disabled={loading} className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#073b82] text-sm font-bold text-white shadow-[0_8px_18px_rgba(7,59,130,.2)] transition hover:bg-[#052f68] disabled:cursor-not-allowed disabled:opacity-60">
                {loading ? "Signing in..." : "Sign In"} <ArrowRight className="h-4 w-4" />
              </button>
            </form>

            <div className="my-6 flex items-center gap-3 text-[11px] font-semibold text-slate-400"><div className="h-px flex-1 bg-slate-200" /> OR <div className="h-px flex-1 bg-slate-200" /></div>

            <button type="button" onClick={async () => { setGoogleError(""); try { await signInWithGoogle(); } catch (err) { setGoogleError(err instanceof Error ? err.message : "Google sign-in failed. Please try again."); } }} disabled={loading} className="flex h-12 w-full items-center justify-center gap-3 rounded-xl border border-[#d9e1ec] bg-white text-sm font-bold text-navy-800 transition hover:border-[#aebed2] hover:bg-slate-50 disabled:opacity-60">
              <svg className="h-5 w-5" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
              Continue with Google
            </button>

            <button type="button" onClick={useDemoAccess} disabled={loading} className="mt-5 flex w-full items-center gap-3 rounded-xl bg-[#edf6ff] px-4 py-3.5 text-left transition hover:bg-[#e2f0ff] disabled:opacity-60">
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#d8edff] text-[#0b55a0]"><Lightbulb className="h-4 w-4" /></span>
              <span className="flex-1"><span className="block text-sm font-bold text-[#0b55a0]">Demo Citizen Access</span><span className="mt-0.5 block text-xs text-slate-500">demo@indiasaathi.ai · password123</span></span>
              <ArrowRight className="h-4 w-4 text-[#0b55a0]" />
            </button>

            <button type="button" onClick={async () => { setValue("email", "admin@indiasaathi.ai"); setValue("password", "admin123"); await authenticate("admin@indiasaathi.ai", "admin123"); }} disabled={loading} className="mt-3 flex w-full items-center gap-3 rounded-xl bg-[#f0f9f0] px-4 py-3.5 text-left transition hover:bg-[#e8f5e8] disabled:opacity-60">
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#d8f0d8] text-success-700"><ShieldCheck className="h-4 w-4" /></span>
              <span className="flex-1"><span className="block text-sm font-bold text-success-700">Demo Admin Access</span><span className="mt-0.5 block text-xs text-slate-500">admin@indiasaathi.ai · admin123</span></span>
              <ArrowRight className="h-4 w-4 text-success-700" />
            </button>

            <p className="mt-7 text-center text-sm text-slate-500">Don't have an account? <Link to="/register" className="font-bold text-[#0b55a0] hover:underline">Create an account</Link></p>
          </div>
        </div>
      </section>
    </main>
  );
}
